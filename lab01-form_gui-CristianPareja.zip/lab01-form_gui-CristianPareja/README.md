Manual del usuario

Formulario GUI con Tkinter

Esta aplicación de escritorio hecha con Python y Tkinter permite almacenar datos personales como: nombre, correo, cédula y saldo inicial y valida que la informacion ingresada sea correcta. Permite exportar esta informacion a un archivo .txt

Ejecucion:
- Abrir una terminal en Visual Studio Code.
- Ejecutar: main.py
- Ingresar los datos y presionar el boton "Guardar".
- Usa el menú Archivo, Exportar a TXT para exportar la información a una ubicacion elegida en tu PC.